
// Component starts as a single node
// fragment is a single node with no markup element.
function App() {
  return (
     <>

     <header className="page-header">
       <h1>Crakit React Starter Kit</h1>
     </header>

     <main>
       <p>jim</p>
     </main>

     </>


  );
}

export default App;
