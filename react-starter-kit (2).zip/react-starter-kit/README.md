# Crakit React Starter

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

 `npm start`  
 Runs the app in the development mode. Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

 
`npm run build`  
Builds the app for production to the build folder. 

  